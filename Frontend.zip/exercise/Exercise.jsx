import { useState, useCallback } from 'react';
import { evaluateLateralRaise } from './lateralRaise';
import { evaluateOverheadPress } from './overheadPress';
import { evaluateDumbbellCurl } from './dumbbellCurl';



const useExerciseLogic = (mode) => {
  const [exerciseState, setExerciseState] = useState({
    leftStage: "down",
    rightStage: "down",
    leftRepDone: false,
    rightRepDone: false,
    repStartTime: null,
    counter: 0,
    repDurations: [],
  });

  const processAngles = useCallback((l_abd, r_abd, r_elb, l_elb ) => {
    if (!l_abd || !r_abd || !r_elb || !l_elb) return;

    switch (mode) {
      case 'lateral_raise':
        evaluateLateralRaise(l_abd, r_abd, r_elb, l_elb, exerciseState, setExerciseState);
        break;
      case 'overhead_press':
        evaluateOverheadPress(l_abd, r_abd, r_elb, l_elb, exerciseState, setExerciseState);
        break;
      case 'dumbbell_curl':
        evaluateDumbbellCurl(l_abd, r_abd, r_elb, l_elb, exerciseState, setExerciseState);
        break;
      default:
        break;
    }
  }, [mode, exerciseState]);

  return { ...exerciseState, processAngles };
};

export default useExerciseLogic;
