export function evaluateDumbbellCurl(l_abd, r_abd, r_elb, l_elb, state, setState) {
  const now = Date.now();

  setState(prev => {
    let {
      leftStage,
      rightStage,
      repStartTime,
      leftRepDone,
      rightRepDone,
      counter,
      repDurations,
    } = prev;

    let newState = { ...prev };

    // Left arm logic
    if (l_elb < 30) {
      newState.leftStage = "down";
      newState.leftRepDone = false;
    } else if (l_elb > 70 && leftStage === "down") {
      newState.leftStage = "up";
      newState.leftRepDone = true;
    }

    // Right arm logic
    if (r_elb < 30) {
      newState.rightStage = "down";
      newState.rightRepDone = false;
    } else if (r_elb > 70 && rightStage === "down") {
      newState.rightStage = "up";
      newState.rightRepDone = true;
    }

    // Rep count condition
    if (newState.leftRepDone && newState.rightRepDone) {
      newState.counter = counter + 1;

      if (repStartTime) {
        const duration = (now - repStartTime) / 1000;
        newState.repDurations = [...repDurations, duration];
      }

      newState.repStartTime = now;
      newState.leftRepDone = false;
      newState.rightRepDone = false;
    }

    return newState;
  });
}
