import React, { useEffect, useRef, useState } from "react";
import useExerciseLogic from "./exercise/Exercise";

const App = () => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const wsRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [exerciseText, setExerciseText] = useState(""); // ✅ new state
  const animationIdRef = useRef(null);
  const { counter, repDurations, processAngles } =
    useExerciseLogic('lateral_raise');

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Camera error:", err);
      }
    };
    startCamera();
  }, []);

  useEffect(() => {
    let lastTime = 0;
    const targetFPS = 16;
    const frameInterval = 1000 / targetFPS;

    const sendFrame = (timestamp) => {
      const elapsed = timestamp - lastTime;
      if (elapsed >= frameInterval) {
        lastTime = timestamp;

        const video = videoRef.current;
        const ws = wsRef.current;
        if (video && ws && ws.readyState === WebSocket.OPEN) {
          const tempCanvas = document.createElement("canvas");
          tempCanvas.width = 320;
          tempCanvas.height = 240;
          const ctx = tempCanvas.getContext("2d");
          ctx.drawImage(video, 0, 0, tempCanvas.width, tempCanvas.height);

          tempCanvas.toBlob(
            (blob) => {
              if (blob) {
                blob.arrayBuffer().then((buffer) => {
                  ws.send(buffer);
                });
              }
            },
            "image/jpeg",
            0.5
          );
        }
      }

      animationIdRef.current = requestAnimationFrame(sendFrame);
    };

    if (connected) {
      animationIdRef.current = requestAnimationFrame(sendFrame);
    }

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
    };
  }, [connected]);

  const startStreaming = () => {
    const ws = new WebSocket("ws://127.0.0.1:8000/ws");
    ws.binaryType = "arraybuffer";

    ws.onopen = () => {
      console.log("🟢 WebSocket connected");
      wsRef.current = ws;
      setConnected(true);
      setStreaming(true);
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (!data.landmarks || !canvasRef.current) return;

        // ✅ Update exercise feedback if present
        if (data.insights.exercise) {
          setExerciseText(`${data.insights.exercise}`);
        } else {
          setExerciseText("No-exercise");
        }

        if (data.insights) {
          console.log("Distance:", data.insights.distance);
          console.log("right elbow angle:", data.insights.right_elb_angle);
          console.log("left elbow angle:", data.insights.left_elb_angle);
        }

        const ctx = canvasRef.current.getContext("2d");
        const cw = canvasRef.current.width;
        const ch = canvasRef.current.height;

        ctx.clearRect(0, 0, cw, ch);

        // Flip landmarks only
        ctx.save();
        ctx.scale(-1, 1);
        ctx.translate(-cw, 0);

        // 🟥 Draw landmarks (flipped)
        data.landmarks.forEach((lm) => {
          const x = lm.x * cw;
          const y = lm.y * ch;
          ctx.beginPath();
          ctx.arc(x, y, 5, 0, 2 * Math.PI);
          ctx.fillStyle = "white";
          ctx.fill();
        });
        ctx.restore();
        switch (data.insights.lateral_raise) {
          case 'lateral_raise':
            processAngles(data.insights.left_abd_angle, data.insights.right_abd_angle, data.insights.left_elb_angle, data.insights.right_elb_angle);
            break;
          case 'overhead_press':
            processAngles(data.insights.left_abd_angle, data.insights.right_abd_angle, data.insights.left_elb_angle, data.insights.right_elb_angle);
            break;
          case 'dumbbell_curl':
            processAngles(data.insights.left_abd_angle, data.insights.right_abd_angle, data.insights.left_elb_angle, data.insights.right_elb_angle);
            break;
          default:
            break;
        }

        if (data.insights?.left_abd_angle && data.insights?.right_abd_angle) {
          processAngles(
            data.insights.left_abd_angle,
            data.insights.right_abd_angle
          );
        }
        data.landmarks.forEach((lm, index) => {
          const x = (1 - lm.x) * cw; // reverse x to match mirrored video
          const y = lm.y * ch;

          ctx.fillStyle = "yellow";
          ctx.font = "14px Montserrat";

          if (index === 13 && data.insights.left_elb_angle !== undefined) {
            ctx.fillText(
              `L-Elb: ${Math.round(data.insights.left_elb_angle)}°`,
              x + 10,
              y - 10
            );
          }
          if (index === 14 && data.insights.right_elb_angle !== undefined) {
            ctx.fillText(
              `R-Elb: ${Math.round(data.insights.right_elb_angle)}°`,
              x + 10,
              y - 10
            );
          }
          if (index === 11 && data.insights.left_abd_angle !== undefined) {
            ctx.fillText(
              `L-Abd: ${Math.round(data.insights.left_abd_angle)}°`,
              x + 10,
              y + 20
            );
          }
          if (index === 12 && data.insights.right_abd_angle !== undefined) {
            ctx.fillText(
              `R-Abd: ${Math.round(data.insights.right_abd_angle)}°`,
              x + 10,
              y + 20
            );
          }
        });

        ctx.restore();
        console.log("✅ JSON received:", data);
      } catch (err) {
        console.warn("❗Non-JSON message received:", event.data);
      }
    };

    ws.onclose = () => {
      console.log("🔴 WebSocket closed");
      setConnected(false);
      setStreaming(false);
    };
  };

  const stopStreaming = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.close();
    }
    if (animationIdRef.current) {
      cancelAnimationFrame(animationIdRef.current);
    }
    setStreaming(false);
    console.log("🛑 Stopped streaming");
  };

  return (
    <div>
      <div style={{ position: "relative", width: 640, height: 480 }}>
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          style={{
            width: 640,
            height: 480,
            transform: "scaleX(-1)",
          }}
        />
        <canvas
          ref={canvasRef}
          width={640}
          height={480}
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            pointerEvents: "none",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 10,
            left: 10,
            backgroundColor: "rgba(0,0,0,0.6)",
            color: "white",
            padding: "8px 12px",
            borderRadius: "8px",
            fontSize: "18px",
            fontWeight: "bold",
          }}
        >
          {exerciseText}
        </div>
      </div>

      <div style={{ marginTop: "1rem" }}>
        <button onClick={startStreaming} disabled={streaming}>
          Start
        </button>
        <button onClick={stopStreaming} disabled={!streaming}>
          Stop
        </button>
      </div>
      <div style={{ marginTop: "2rem" }}>
        <p>Reps: {counter}</p>
        {repDurations.length > 0 && (
          <p>
            Last rep duration:{" "}
            {repDurations[repDurations.length - 1].toFixed(2)}s
          </p>
        )}
      </div>
    </div>
  );
};

export default App;
