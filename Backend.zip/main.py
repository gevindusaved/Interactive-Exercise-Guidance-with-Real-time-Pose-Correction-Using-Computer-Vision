import cv2
import numpy as np
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from starlette.websockets import WebSocketDisconnect
from fastapi.responses import HTMLResponse
from services.pose_module import poseDetector
from services.smoother import Smoother
from services.exercise import Exercises
from services.pose_session import PoseSession
from services.estimator import DistanceEstimator

app = FastAPI()

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize pose detector and exercise tracker
smoother = Smoother(alpha=0.5)
detector = poseDetector(smoother=smoother)
estimator = DistanceEstimator(known_width_m=0.4, fov_deg=60, image_width_px=640)
exercise_mode = "lateral_raise"


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    try:
        while True:
            data = await websocket.receive_bytes()
            npimg = np.frombuffer(data, dtype=np.uint8)
            frame = cv2.imdecode(npimg, cv2.IMREAD_COLOR)

            if frame is None:
                print("❌ Failed to decode image")
                continue
            frame = cv2.resize(frame, (320, 240))

            detector.findPose(frame, draw=False)
            landmarks = detector.findPosition(frame, draw=False)

            lm_dict = {lm["id"]: (lm["x"], lm["y"]) for lm in landmarks}

            exercise = Exercises(lm_dict, detector=detector, smoother=smoother, estimator=estimator, frame=frame, font=cv2.FONT_HERSHEY_SIMPLEX)
            session = PoseSession(detector=detector, exercise=exercise, estimator=estimator, exercise_mode=exercise_mode)
            if not landmarks:
                await websocket.send_json({"error": "No person detected"})
                continue

            insights = session.analyze_exercise(frame, landmarks)

            await websocket.send_json({
                "landmarks": landmarks,
                "insights": insights
            })

    except WebSocketDisconnect:
        print("❌ WebSocket disconnected")

