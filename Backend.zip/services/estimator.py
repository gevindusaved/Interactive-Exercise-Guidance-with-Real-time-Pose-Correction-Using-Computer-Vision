import math

class DistanceEstimator:
    def __init__(self, known_width_m, focal_length_px=None, fov_deg=None, image_width_px=None):
        self.known_width = known_width_m
        if focal_length_px is not None:
            self.focal_length = focal_length_px
        elif fov_deg is not None and image_width_px is not None:
            self.focal_length = (image_width_px / 2) / math.tan(math.radians(fov_deg / 2))
        else:
            raise ValueError("Must provide either focal_length_px or (fov_deg and image_width_px).")

    def distance(self, pixel_width):
        if pixel_width <= 0:
            return None
        return (self.known_width * self.focal_length) / pixel_width
