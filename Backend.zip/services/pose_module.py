import cv2
import mediapipe as mp
import numpy as np

class Smoother:
    def __init__(self, alpha=0.5):
        self.alpha = alpha
        self.prev_values = {}

    def smooth(self, key, new_value):
        if key not in self.prev_values:
            self.prev_values[key] = new_value
        else:
            self.prev_values[key] = self.alpha * new_value + (1 - self.alpha) * self.prev_values[key]
        return self.prev_values[key]


class poseDetector:
    def __init__(self, smoother, static_image_mode=False, model_complexity=1,
                 smooth_landmarks=True, enable_segmentation=False, smooth_segmentation=True,
                 min_detection_confidence=0.5, min_tracking_confidence=0.5):
        self.smoother = smoother

        self.mpDraw = mp.solutions.drawing_utils
        self.mpPose = mp.solutions.pose
        self.pose = self.mpPose.Pose(
            static_image_mode=static_image_mode,
            model_complexity=model_complexity,
            smooth_landmarks=smooth_landmarks,
            enable_segmentation=enable_segmentation,
            smooth_segmentation=smooth_segmentation,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence
        )

    def findPose(self, img, draw=True):
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.pose.process(img_rgb)

        if self.results.pose_landmarks and draw:
            self.mpDraw.draw_landmarks(img, self.results.pose_landmarks, self.mpPose.POSE_CONNECTIONS)
        return img

    def findPosition(self, img, draw=False):
        landmarks = []
        if self.results.pose_landmarks:
            h, w, _ = img.shape
            for id, lm in enumerate(self.results.pose_landmarks.landmark):
                # Use normalized coordinates (already in lm.x and lm.y)
                cx = self.smoother.smooth(f"{id}_x", lm.x)
                cy = self.smoother.smooth(f"{id}_y", lm.y)

                landmarks.append({
                    "id": id,
                    "x": round(cx, 6),
                    "y": round(cy, 6)
                })

                if draw:
                    px, py = int(cx * w), int(cy * h)
                    
        return landmarks

    def calculate_angle(self, a, b, c):
        a = np.array(a)
        b = np.array(b)
        c = np.array(c)
        radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
        angle = np.abs(radians * 180.0 / np.pi)
        if angle > 180.0:
            angle = 360.0 - angle
        return angle