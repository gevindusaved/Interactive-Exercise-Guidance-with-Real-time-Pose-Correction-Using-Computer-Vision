

class PoseSession:
    def __init__(self, detector, exercise, estimator, exercise_mode):
        self.detector = detector
        self.exercise = exercise
        self.estimator = estimator
        self.exercise_mode = exercise_mode
        self.min_dist = 0.5  # Example: in meters
        self.max_dist = 3.0


    def analyze_exercise(self, frame, landmarks):
        results = {}

        if not landmarks:
            results["error"] = "No person detected"
            return results

        joints = {lm["id"]: (lm["x"], lm["y"]) for lm in landmarks}
        r_shoulder = joints.get(12)
        l_shoulder = joints.get(11)

        if r_shoulder and l_shoulder:
            pixel_width = abs(r_shoulder[0] * frame.shape[1] - l_shoulder[0] * frame.shape[1])
            distance = self.exercise.estimator.distance(pixel_width)
            results["distance"] = round(distance, 2) if distance else None

            if distance:
                results["status"] = "ok"
                if distance < self.exercise.min_dist or distance > self.exercise.max_dist:
                    results["status"] = "out_of_range"
                else:
                    results["status"] = "in_range"
                    # Perform exercise logic
                    if self.exercise_mode == "lateral_raise":
                        r_elb, l_elb, l_abd, r_abd = self.exercise.lateral_raise()
                    elif self.exercise_mode == "overhead_press":
                        r_elb, l_elb, l_abd, r_abd = self.exercise.overhead_press()
                    elif self.exercise_mode == "dumbbell_curl":
                        r_elb, l_elb, l_abd, r_abd = self.exercise.dumbell_curl()
                    results["exercise"] = self.exercise_mode
                    if r_elb is not None and l_elb is not None and l_abd is not None and r_abd is not None:
                        results["right_elb_angle"] = r_elb
                        results["left_elb_angle"] = l_elb
                        results["left_abd_angle"] = l_abd
                        results["right_abd_angle"] = r_abd

        return results

