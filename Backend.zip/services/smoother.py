class Smoother:
    def __init__(self, alpha=0.3):
        self.alpha = alpha
        self.prev_values = {}

    def smooth(self, key, new_value):
        if key not in self.prev_values:
            self.prev_values[key] = new_value
        else:
            self.prev_values[key] = self.alpha * new_value + (1 - self.alpha) * self.prev_values[key]
        return self.prev_values[key]
