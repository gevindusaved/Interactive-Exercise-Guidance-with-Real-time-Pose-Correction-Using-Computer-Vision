import mediapipe as mp
class Exercises:
    def __init__(self, lmList, detector, smoother, estimator, frame, font):
        self.lmList = lmList
        self.detector = detector
        self.smoother = smoother
        self.estimator = estimator
        self.frame = frame
        self.font = font
        self.min_dist = 1.5 
        self.max_dist = 6.0

    def get_joints(self):
        try:
            return {
                name: self.lmList[getattr(mp.solutions.pose.PoseLandmark, name).value]
                for name in [
                    "LEFT_HIP", "LEFT_ELBOW", "LEFT_WRIST",
                    "RIGHT_HIP", "RIGHT_ELBOW", "RIGHT_WRIST",
                    "LEFT_SHOULDER", "RIGHT_SHOULDER"
                ]
            }
        except KeyError as e:
            print(f"Joint index error — landmark list may be incomplete. Missing: {e}")
            return {}


    def dumbell_curl(self):
        joints = self.get_joints()
        if not joints:
            return None, None
        try:
            l_abd_raw = self.detector.calculate_angle(joints["LEFT_HIP"], joints["LEFT_SHOULDER"], joints["LEFT_ELBOW"])
            r_abd_raw = self.detector.calculate_angle(joints["RIGHT_HIP"], joints["RIGHT_SHOULDER"], joints["RIGHT_ELBOW"])
            l_abd = self.smoother.smooth("l_abd", l_abd_raw)
            r_abd = self.smoother.smooth("r_abd", r_abd_raw)
            l_elb_raw = self.detector.calculate_angle(joints["LEFT_SHOULDER"], joints["LEFT_ELBOW"], joints["LEFT_WRIST"])
            r_elb_raw = self.detector.calculate_angle(joints["RIGHT_SHOULDER"], joints["RIGHT_ELBOW"], joints["RIGHT_WRIST"])
            l_elb = self.smoother.smooth("l_elb", l_elb_raw)
            r_elb = self.smoother.smooth("r_elb", r_elb_raw)
            return r_elb, l_elb, l_abd, r_abd
        except KeyError as e:
            print(f"Missing joint: {e}")
            return None, None

    def lateral_raise(self):
        joints = self.get_joints()
        if not joints:
            print("No Joints are found")
            return None, None
        try:

            l_abd_raw = self.detector.calculate_angle(joints["LEFT_HIP"], joints["LEFT_SHOULDER"], joints["LEFT_ELBOW"])
            r_abd_raw = self.detector.calculate_angle(joints["RIGHT_HIP"], joints["RIGHT_SHOULDER"], joints["RIGHT_ELBOW"])
            l_abd = self.smoother.smooth("l_abd", l_abd_raw)
            r_abd = self.smoother.smooth("r_abd", r_abd_raw)
            l_elb_raw = self.detector.calculate_angle(joints["LEFT_SHOULDER"], joints["LEFT_ELBOW"], joints["LEFT_WRIST"])
            r_elb_raw = self.detector.calculate_angle(joints["RIGHT_SHOULDER"], joints["RIGHT_ELBOW"], joints["RIGHT_WRIST"])
            l_elb = self.smoother.smooth("l_elb", l_elb_raw)
            r_elb = self.smoother.smooth("r_elb", r_elb_raw)
            return r_elb, l_elb, l_abd, r_abd
        except KeyError as e:
            print(f"Missing joint: {e}")
            return "None1", "None2", "None3", "None4"

    def overhead_press(self):
        joints = self.get_joints()
        if not joints:
            return None, None
        try:
            l_abd_raw = self.detector.calculate_angle(joints["LEFT_HIP"], joints["LEFT_SHOULDER"], joints["LEFT_ELBOW"])
            r_abd_raw = self.detector.calculate_angle(joints["RIGHT_HIP"], joints["RIGHT_SHOULDER"], joints["RIGHT_ELBOW"])
            l_abd = self.smoother.smooth("l_abd", l_abd_raw)
            r_abd = self.smoother.smooth("r_abd", r_abd_raw)
            l_elb_raw = self.detector.calculate_angle(joints["LEFT_SHOULDER"], joints["LEFT_ELBOW"], joints["LEFT_WRIST"])
            r_elb_raw = self.detector.calculate_angle(joints["RIGHT_SHOULDER"], joints["RIGHT_ELBOW"], joints["RIGHT_WRIST"])
            l_elb = self.smoother.smooth("l_elb", l_elb_raw)
            r_elb = self.smoother.smooth("r_elb", r_elb_raw)
            return r_elb, l_elb, l_abd, r_abd
        except KeyError as e:
            print(f"Missing joint: {e}")
            return None, None
